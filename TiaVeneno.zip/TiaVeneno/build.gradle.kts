// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
}

buildscript {
    repositories {
        google()  // debe estar presente
        mavenCentral()
    }
    dependencies {
        classpath ("com.android.tools.build:gradle:8.0.2") // o la versión que uses
        classpath ("androidx.navigation:navigation-safe-args-gradle-plugin:2.7.0") // si usas safe args (opcional)
    }
}