plugins {
    alias(libs.plugins.android.application)
    id ("androidx.navigation.safeargs")
}

android {
    namespace = "com.example.tiaveneno"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.tiaveneno"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    buildFeatures {
        viewBinding = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

}

dependencies {

    implementation ("androidx.navigation:navigation-fragment:2.7.0")

    implementation ("androidx.navigation:navigation-ui:2.7.0")

    implementation("com.airbnb.android:lottie:5.0.0")
    //Libreria que permite posicionar elementos en pantalla
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    //Iconos
    implementation("com.google.android.material:material:1.12.0")

    implementation ("androidx.recyclerview:recyclerview:1.3.2")

    implementation ("androidx.viewpager2:viewpager2:1.0.0")

    implementation(files("libs/jtds-1.3.1.jar"))

    implementation(files("libs/mssql-jdbc-12.10.0.jre11.jar"))

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}