package com.example.tiaveneno.Connection;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionBD {
    final String ip = "databasesupnujeanpierre.database.windows.net";
    final String usuario = "sqlAdmin@databasesupnujeanpierre";
    final String password = "ybzz-vr20-d17y";
    final String basedatos = "TiaVeneno";

    @SuppressLint("NewApi")
    public Connection connect() {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection;
        String connectionURL;
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");

            connectionURL = "jdbc:jtds:sqlserver://databasesupnujeanpierre.database.windows.net:1433;DatabaseName=TiaVeneno;" +
                    "user=sqlAdmin@databasesupnujeanpierre;" +
                    "password=ybzz-vr20-d17y;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;ssl=request";

            Log.i("ConnectionBD", "Connection URL: " + connectionURL);
            connection = DriverManager.getConnection(connectionURL);
            return connection;

        } catch (Exception e) {
            Log.e("ConnectionBD", "Error al conectar a SQL Azure: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
