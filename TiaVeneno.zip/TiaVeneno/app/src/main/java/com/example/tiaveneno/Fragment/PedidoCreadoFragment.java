package com.example.tiaveneno.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tiaveneno.PedidosVendedorActivity;
import com.example.tiaveneno.R;
import com.example.tiaveneno.Repository.PedidoRepository;
import com.example.tiaveneno.models.Pedido;


public class PedidoCreadoFragment extends Fragment {
    private PedidoRepository pedidoRepository;
    TextView tvidPedido;

    public static PedidoCreadoFragment newInstance() {
        PedidoCreadoFragment fragment = new PedidoCreadoFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pedido_creado, container, false);

        TextView tvTotal=view.findViewById(R.id.tvTotal);
        TextView tvcliente=view.findViewById(R.id.tvNombreCliente);
        tvidPedido=view.findViewById(R.id.tvIdPedido);
        Button btnverPedidos=view.findViewById(R.id.btnVerPedidos);
        Button btnnuevoPedido=view.findViewById(R.id.btnNuevoPedido);

        btnverPedidos.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), PedidosVendedorActivity.class);
            startActivity(intent);
        });
        btnnuevoPedido.setOnClickListener(v -> {
            Fragment nuevoPedidoFragment = new NombreClienteFragment(); // tu fragment nuevo

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, nuevoPedidoFragment)
                    .addToBackStack(null)
                    .commit();
        });


        tvTotal.setText(String.format("S/.%.2f", TuPedidoFragment.Total));
        tvcliente.setText(NombreClienteFragment.nombreCliente);


        return view;
    }
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        pedidoRepository = new PedidoRepository();
        Pedido pedido = new Pedido(); // Llena los campos necesarios aquí

        pedidoRepository.crearPedido(requireContext(), pedido, new PedidoRepository.PedidoCallback() {
            @Override
            public void onSuccess() {
                tvidPedido.setText("Pedido: ORD"+PedidoRepository.idPedido);
                Toast.makeText(requireContext(), "Pedido creado exitosamente", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onError(String mensaje) {
                Toast.makeText(requireContext(), "Error: " + mensaje, Toast.LENGTH_LONG).show();
            }
        });

    }
}