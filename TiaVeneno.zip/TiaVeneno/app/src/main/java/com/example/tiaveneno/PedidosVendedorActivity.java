package com.example.tiaveneno;

import static com.example.tiaveneno.DatosGlobales.DatosGlobales.idUsuarioActual;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.tiaveneno.Adapter.PedidoAdapter;
import com.example.tiaveneno.Fragment.NombreClienteFragment;
import com.example.tiaveneno.Repository.PedidoRepository;
import com.example.tiaveneno.databinding.ActivityPedidosVendedorBinding;
import com.example.tiaveneno.databinding.ActivityPedidosVendedorBinding;
import com.example.tiaveneno.models.Pedido;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class PedidosVendedorActivity extends AppCompatActivity {

    private Pedido pedido;
    private PedidoAdapter adapter;
    private List<Pedido> listaPedidos;
    private ActivityPedidosVendedorBinding binding;
    private PedidoRepository pedidoRepository;

    MaterialButton btnActualizarPedido;
    MaterialButton btnLogout ;

    MaterialButton btnAnadirPedido;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPedidosVendedorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        listaPedidos = new ArrayList<>();
        pedidoRepository = new PedidoRepository();

        btnAnadirPedido = findViewById(R.id.bntAnadirPedido);
        btnLogout = findViewById(R.id.btnLogout);
        btnActualizarPedido=findViewById((R.id.btnActualizarPedido));

        adapter = new PedidoAdapter(listaPedidos, pedidoSeleccionado -> {
            PedidosVendedorActivity.this.pedido = pedidoSeleccionado;
            cambiarEstadoPedido();
        });


        binding.recyclerViewPedidos.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerViewPedidos.setAdapter(adapter);

        cargarTodosPedidosConExecutor(true);

        binding.btnPedidoActivos.setOnClickListener(v -> cargarTodosPedidosConExecutor(true));
        binding.btnPedidoCompletos.setOnClickListener(v -> cargarTodosPedidosConExecutor(false));

        btnAnadirPedido.setOnClickListener(v -> {
            // Mostrar el contenedor del fragmento
            FrameLayout container = findViewById(R.id.fragment_container);
            container.setVisibility(View.VISIBLE);

            // Cargar el fragment en ese contenedor
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new NombreClienteFragment())
                    .addToBackStack(null) // para que el botón atrás funcione
                    .commit();
        });

        btnLogout.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        });

        binding.btnActualizarPedido.setOnClickListener(v -> cargarTodosPedidosConExecutor(true));

    }

    private void cargarTodosPedidosConExecutor(boolean activos) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            List<Pedido> pedidos = PedidoRepository.obtenerPedidos();
            runOnUiThread(() -> {
                if (pedidos != null && !pedidos.isEmpty()) {
                    adapter.updatePedidos(pedidos);
                    adapter.filtrarPedidosPorEstado(activos);
                } else {
                    Toast.makeText(this, "No hay pedidos para mostrar", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
    private void cambiarEstadoPedido() {
        if (pedido == null) {
            Toast.makeText(this, "Seleccione un pedido primero", Toast.LENGTH_SHORT).show();
            return;
        }

        String usuarioActual = idUsuarioActual;
        PedidoRepository repository = new PedidoRepository();
        int idUsuario = repository.obtenerIdUsuarioPorNombre(usuarioActual);
        int idPedido = Integer.parseInt(pedido.getId().replaceFirst("ORD",""));

        String siguienteEstado = PedidoRepository.obtenerSiguienteEstado(pedido.getEstado());

        if (siguienteEstado != null) {
            new Thread(() -> {
                boolean ok = repository.cambiarEstadoPedido(
                        idPedido,
                        siguienteEstado,
                        idUsuario
                );

                runOnUiThread(() -> {
                    if (ok) {
                        Toast.makeText(this, "Estado actualizado a " + siguienteEstado, Toast.LENGTH_SHORT).show();
                        pedido.setEstado(siguienteEstado);
                        adapter.notifyDataSetChanged(); // refrescar lista si es necesario
                    } else {
                        Toast.makeText(this, "Error al actualizar el estado", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
        } else {
            Toast.makeText(this, "Este pedido ya está completado.", Toast.LENGTH_SHORT).show();
        }
    }
}