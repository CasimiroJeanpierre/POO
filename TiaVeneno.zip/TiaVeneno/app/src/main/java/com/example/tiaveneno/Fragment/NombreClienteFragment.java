package com.example.tiaveneno.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.tiaveneno.PedidosVendedorActivity;
import com.example.tiaveneno.R;

public class NombreClienteFragment extends Fragment {

    public static String nombreCliente;

    public NombreClienteFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_nombre_cliente, container, false);

        EditText editTextNombre = view.findViewById(R.id.editTextNombre);
        Button btnContinuar = view.findViewById(R.id.btnContinuar);
        Button btnAtras = view.findViewById(R.id.btnAtras);


        btnAtras.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), PedidosVendedorActivity.class);
            startActivity(intent);
        });

        btnContinuar.setOnClickListener(v -> {
            nombreCliente = editTextNombre.getText().toString();
            if (nombreCliente.isEmpty()) {
                editTextNombre.setError("Este campo es obligatorio");
                editTextNombre.requestFocus();
                return; // No continúa si está vacío
            }

            ProductosFragment nuevoFragment = new ProductosFragment();
            Bundle args = new Bundle();
            args.putString("nombreCliente", nombreCliente);
            nuevoFragment.setArguments(args);

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, nuevoFragment)
                    .addToBackStack(null)
                    .commit();
        });
        return view;
    }
}