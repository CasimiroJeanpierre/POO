package com.example.tiaveneno.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.NonNull;
import android.widget.Button;
import com.example.tiaveneno.R;
import com.example.tiaveneno.models.DetallePedido;
import java.util.List;

public class AñadirProductoAdapter extends RecyclerView.Adapter<AñadirProductoAdapter.ViewHolder> {

    public static List<DetallePedido> listaDetalles;

    public static double Total;

    public AñadirProductoAdapter(List<DetallePedido> listaDetalles) {
        this.listaDetalles = listaDetalles;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detalle_pedido, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DetallePedido detalle = listaDetalles.get(position);
        holder.tvNombreProducto.setText(detalle.getProducto());
        holder.tvPrecioProducto.setText(String.format("S/.%.2f", detalle.getPrecioUnitario()));
        holder.tvCantidad.setText(String.valueOf(detalle.getCantidad()));

        holder.btnMas.setOnClickListener(v -> {
            if (detalle.getCantidad() < 10) {
                detalle.setCantidad(detalle.getCantidad() + 1);
                notifyItemChanged(position); // Refresca solo este item
            }
        });

        holder.btnMenos.setOnClickListener(v -> {
            if (detalle.getCantidad() > 1) {
                detalle.setCantidad(detalle.getCantidad() - 1);
                notifyItemChanged(position);
            }
        });
    }
    @Override
    public int getItemCount() {
        return listaDetalles.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombreProducto, tvCantidad, tvPrecioProducto;
        Button btnMenos, btnMas;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombreProducto = itemView.findViewById(R.id.tvNombreProducto);
            tvPrecioProducto=itemView.findViewById(R.id.tvPrecioProducto);
            tvCantidad = itemView.findViewById(R.id.tvCantidad);
            btnMenos = itemView.findViewById(R.id.btnMenos);
            btnMas = itemView.findViewById(R.id.btnMas);
        }
    }
    public double getPrecioTotal() {

        double total = 0;
        for (DetallePedido detalle : listaDetalles) {
            total += detalle.getCantidad() * detalle.getPrecioUnitario();
        }
        Total=total;
        return total;
    }
}
