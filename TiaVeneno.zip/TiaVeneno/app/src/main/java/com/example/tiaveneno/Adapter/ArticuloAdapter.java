package com.example.tiaveneno.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.tiaveneno.R;
import com.example.tiaveneno.models.DetallePedido;
import java.util.List;

public class ArticuloAdapter extends RecyclerView.Adapter<ArticuloAdapter.ViewHolder > {
    private List<DetallePedido> detalles;

    public ArticuloAdapter(List<DetallePedido> detalles) {
        this.detalles = detalles;
    }

    @NonNull
    @Override
    public ViewHolder  onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_articulos, parent, false);
        return new ViewHolder (v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder  holder, int position) {
        DetallePedido detalle = detalles.get(position);
        holder.tvNombreProducto.setText(detalle.getProducto());
        holder.tvCantidad.setText(String.valueOf("x"+detalle.getCantidad()));
        holder.tvPrecioProducto.setText(String.format("S/.%.2f", detalle.getPrecioUnitario()));
    }

    @Override
    public int getItemCount() {
        return detalles.size();
    }

    static class ViewHolder  extends RecyclerView.ViewHolder {
        TextView tvNombreProducto, tvPrecioProducto, tvCantidad;

        public ViewHolder (@NonNull View itemView) {
            super(itemView);
            tvNombreProducto = itemView.findViewById(R.id.tvNombreProducto);
            tvPrecioProducto = itemView.findViewById(R.id.tvPrecio);
            tvCantidad = itemView.findViewById(R.id.tvCantidad);

        }
    }
}