package com.example.tiaveneno.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.tiaveneno.R;
import com.example.tiaveneno.models.DetallePedido;
import com.example.tiaveneno.models.Producto;

import java.util.ArrayList;
import java.util.List;

public class ProductoAdapter extends RecyclerView.Adapter<ProductoAdapter.ProductoViewHolder> {

    private List<Producto> productos;
    private Runnable onSeleccionCambio;
    private List<Producto> listaProductosSeleccionados = new ArrayList<>();
    public ProductoAdapter(List<Producto> productos) {
        this.productos = productos;
    }

    @NonNull
    @Override
    public ProductoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_producto, parent, false);
        return new ProductoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductoViewHolder holder, int position) {
        Producto producto = productos.get(position);
        holder.nombre.setText(producto.getNombre());
        holder.precio.setText(String.format("S/. %.2f", producto.getPrecio()));

        holder.cbSeleccionado.setOnCheckedChangeListener(null); // evita errores de reciclado
        holder.cbSeleccionado.setChecked(producto.isSeleccionado());

        holder.cbSeleccionado.setOnCheckedChangeListener((buttonView, isChecked) -> {
            producto.setSeleccionado(isChecked);
        });

        holder.cbSeleccionado.setOnCheckedChangeListener((buttonView, isChecked) -> {
            producto.setSeleccionado(isChecked);

            if (isChecked) {
                if (!listaProductosSeleccionados.contains(producto)) {
                    listaProductosSeleccionados.add(producto);
                }
            } else {
                listaProductosSeleccionados.remove(producto);
            }

            if (onSeleccionCambio != null) {
                onSeleccionCambio.run();
            }
        });
    }
    public void setOnSeleccionCambio(Runnable onSeleccionCambio) {
        this.onSeleccionCambio = onSeleccionCambio;
    }

    @Override
    public int getItemCount() {
        return (productos == null) ? 0 : productos.size();
    }

    public static class ProductoViewHolder extends RecyclerView.ViewHolder {
        TextView nombre, precio;
        CheckBox cbSeleccionado;

        public ProductoViewHolder(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.tvNombreProducto);
            precio= itemView.findViewById(R.id.tvPrecio);
            cbSeleccionado = itemView.findViewById(R.id.cbSeleccionado);

        }
    }
    public List<DetallePedido> obtenerSeleccionados() {
        List<DetallePedido> listaDetallePedido = new ArrayList<>();

        for (Producto p : listaProductosSeleccionados) {
            DetallePedido detalle = new DetallePedido();
            detalle.setProducto(p.getNombre());
            detalle.setPrecioUnitario(p.getPrecio());
            detalle.setCantidad(1); // Cantidad 1 porque no hay repetidos
            listaDetallePedido.add(detalle);
        }

        return listaDetallePedido;  // Muy importante retornar la lista creada
    }




}
