package com.example.tiaveneno.Fragment;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.tiaveneno.Adapter.AñadirProductoAdapter;
import com.example.tiaveneno.R;
import com.example.tiaveneno.models.DetallePedido;

import org.w3c.dom.Text;

import java.util.List;


public class TuPedidoFragment extends Fragment {

    public static Double Total;
    RecyclerView recyclerView;
    AñadirProductoAdapter adapter;
    List<DetallePedido> listaPedido;
    Button btnContinuar;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_tu_pedido, container, false);


        TextView tvtotal=view.findViewById(R.id.tvTotal);
        TextView tvcliente=view.findViewById(R.id.tvCliente);

        tvcliente.setText("Para: "+NombreClienteFragment.nombreCliente);

        if (getArguments() != null) {
            listaPedido = (List<DetallePedido>) getArguments().getSerializable("listaPedido");
        }

        // Ahora configura el RecyclerView
        recyclerView = view.findViewById(R.id.recyclerProductosSeleccionados); // usa tu ID real
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new AñadirProductoAdapter(listaPedido);
        recyclerView.setAdapter(adapter);
        btnContinuar= view.findViewById(R.id.btnContinuar);
        Button btnAtras = view.findViewById(R.id.btnAtras);

        btnContinuar.setOnClickListener(v -> {
            Fragment confirmarFragment = new PedidoCreadoFragment();

            // Cambia el fragmento
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, confirmarFragment) // Asegúrate que R.id.fragment_container es el id del contenedor en tu activity
                    .addToBackStack(null) // Opcional: permite volver con el botón atrás
                    .commit();
        });

        btnAtras.setOnClickListener(v -> {
            Fragment nuevoPedidoFragment = new ProductosFragment(); // tu fragment nuevo

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, nuevoPedidoFragment)
                    .addToBackStack(null)
                    .commit();
        });
        if (listaPedido != null && !listaPedido.isEmpty()) {
            adapter = new AñadirProductoAdapter(listaPedido);
            recyclerView.setAdapter(adapter);


            // Ahora sí que podemos usar el método getPrecioTotal()
            tvtotal.setText(String.format("S/.%.2f", adapter.getPrecioTotal()));
            Total=adapter.getPrecioTotal();


            // Opcional: actualiza el total cuando cambien los datos del adaptador
            adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                private void actualizarTotal() {
                    tvtotal.setText(String.format("S/.%.2f", adapter.getPrecioTotal()));;
                    Total=adapter.getPrecioTotal();
                }

                @Override
                public void onChanged() {
                    actualizarTotal();
                }

                @Override
                public void onItemRangeChanged(int positionStart, int itemCount) {
                    actualizarTotal();
                }
            });
        } else {
            tvtotal.setText("S/.0.00");
        }
        return view;
    }
}