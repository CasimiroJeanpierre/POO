package com.example.tiaveneno.DatosGlobales;

public class DatosGlobales {
    public static String idUsuarioActual="";
}
