package com.example.tiaveneno.Fragment;

import static com.example.tiaveneno.Repository.ProductoRepository.obtenerProductos;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.tiaveneno.Adapter.ProductoAdapter;
import com.example.tiaveneno.R;
import com.example.tiaveneno.models.DetallePedido;
import com.example.tiaveneno.models.Producto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
public class ProductosFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProductoAdapter adapter;
    private List<Producto> listaProductos;
    List<DetallePedido> listaPedido = new ArrayList<>();
    private Button btnvercarrito;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_productos, container, false);

        String nombreCliente = getArguments() != null ? getArguments().getString("nombreCliente") : null;
        Log.d("ProductosFragment", "Nombre cliente: " + nombreCliente);

        recyclerView = view.findViewById(R.id.recyclerProductos);
        btnvercarrito = view.findViewById(R.id.btnVerCarrito);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        Button btnAtras = view.findViewById(R.id.btnAtras);


        new Thread(() -> {
            listaProductos = obtenerProductos();

            if (listaProductos != null) {
                getActivity().runOnUiThread(() -> {
                    adapter = new ProductoAdapter(listaProductos);
                    adapter.setOnSeleccionCambio(() -> actualizarTextoBoton(btnvercarrito));
                    recyclerView.setAdapter(adapter);

                    btnvercarrito.setOnClickListener(v -> {
                        if (adapter != null) {
                            listaPedido = adapter.obtenerSeleccionados();

                            if (listaPedido == null || listaPedido.isEmpty()) {
                                Toast.makeText(requireContext(), "Debes seleccionar al menos un producto", Toast.LENGTH_SHORT).show();
                                return; // Detiene el flujo si no hay productos
                            }
                            // Obtener lista de DetallePedido directamente
                            listaPedido = adapter.obtenerSeleccionados();

                            TuPedidoFragment fragment = new TuPedidoFragment();

                            Bundle args = new Bundle();
                            args.putSerializable("listaPedido", (Serializable) listaPedido);
                            fragment.setArguments(args);

                            requireActivity().getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.fragment_container, fragment)
                                    .addToBackStack(null)
                                    .commit();
                        }
                    });
                    btnAtras.setOnClickListener(v -> {
                        Fragment nuevoPedidoFragment = new NombreClienteFragment(); // tu fragment nuevo

                        requireActivity().getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.fragment_container, nuevoPedidoFragment)
                                .addToBackStack(null)
                                .commit();
                    });

                });
            }
        }).start();

        return view;

    }
    private void actualizarTextoBoton(Button btn) {
        if (adapter != null) {
            int cantidad = adapter.obtenerSeleccionados().size();
            btn.setText("Ver Carrito (" + cantidad + ")");
        }
    }

}