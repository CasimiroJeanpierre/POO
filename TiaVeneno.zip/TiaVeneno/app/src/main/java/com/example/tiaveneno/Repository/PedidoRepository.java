package com.example.tiaveneno.Repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.example.tiaveneno.Adapter.AñadirProductoAdapter;
import com.example.tiaveneno.Adapter.PedidoAdapter;
import com.example.tiaveneno.Connection.ConnectionBD;
import com.example.tiaveneno.Fragment.NombreClienteFragment;
import com.example.tiaveneno.Fragment.NotasEspecialesFragment;
import com.example.tiaveneno.models.DetallePedido;
import com.example.tiaveneno.models.Pedido;
import com.example.tiaveneno.models.Producto;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PedidoRepository {

    private List<Producto> productosDisponibles;
    public static int idPedido;
    public interface PedidoCallback {
        void onSuccess();
        void onError(String mensaje);
    }

    public static List<Pedido> obtenerPedidos() {
        Map<String, Pedido> pedidosMap = new HashMap<>();
        ConnectionBD connetionBD = new ConnectionBD();
        Connection connection = connetionBD.connect();

        if (connection != null) {
            try {
                String sql = "SELECT  IdPedido,Cliente,EstadoPedido,ObservacionesEspeciales,Producto, Cantidad, PrecioUnitario,Subtotal,MinutosTranscurridos,Total FROM  VistaPedidos";
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    String id = "ORD"+rs.getString("IdPedido");

                    // Si el pedido no existe en el mapa, crearlo
                    if (!pedidosMap.containsKey(id)) {
                        String cliente = rs.getString("Cliente");
                        String estado = rs.getString("EstadoPedido");
                        String total = rs.getString("Total");
                        String observaciones = rs.getString("ObservacionesEspeciales");
                        int minutos = rs.getInt("MinutosTranscurridos");
                        String tiempo = "hace " + minutos + " minutos";

                        Pedido pedido = new Pedido(id, cliente, estado, observaciones, total, tiempo);
                        pedidosMap.put(id, pedido);
                    }

                    // Crear el detalle del producto
                    String producto = rs.getString("Producto");
                    int cantidad = rs.getInt("Cantidad");
                    double precioUnitario = rs.getDouble("PrecioUnitario");
                    double subtotal = rs.getDouble("Subtotal");

                    DetallePedido detalle = new DetallePedido(producto, cantidad, precioUnitario, subtotal);

                    // Añadir el detalle al pedido correspondiente
                    pedidosMap.get(id).agregarDetalle(detalle);
                }

                rs.close();
                stmt.close();
                connection.close();

            } catch (SQLException e) {
                Log.e("SQL_ERROR", "Error al consultar la vista", e);
                return null;
            }
        } else {
            Log.e("CONN_ERROR", "No se pudo conectar a la BD");
            return null;
        }

        // Devolver la lista de pedidos con detalles
        return new ArrayList<>(pedidosMap.values());
    }
    public boolean cambiarEstadoPedido(int idPedido, String nuevoEstado, int cambiadoPor) {
        ConnectionBD connetionBD = new ConnectionBD();
        Connection connection = connetionBD.connect();

        if (connection != null) {
            try {
                String sql = "{call sp_CambiarEstadoPedido(?, ?, ?)}";
                CallableStatement stmt = connection.prepareCall(sql);

                stmt.setInt(1, idPedido);
                stmt.setString(2, nuevoEstado);
                stmt.setInt(3, cambiadoPor);

                ResultSet rs = stmt.executeQuery();

                boolean exito = false;

                while (rs.next()) {
                    String resultado = rs.getString("Resultado");
                    if ("SUCCESS".equalsIgnoreCase(resultado)) {
                        exito = true;
                    }
                }

                rs.close();
                stmt.close();
                connection.close();

                return exito;

            } catch (SQLException e) {
                Log.e("SQL_ERROR", "Error al ejecutar el procedimiento", e);
                return false;
            }
        } else {
            Log.e("CONN_ERROR", "No se pudo conectar a la BD");
            return false;
        }
    }
    public static String obtenerSiguienteEstado(String estadoActual) {
        switch (estadoActual) {
            case "Recibido":
                return "En Preparación";
            case "En Preparación":
                return "Listo para Recoger";
            case "Listo para Recoger":
                return "Completado";
            default:
                return null; // ya está completado o estado desconocido
        }
    }
    public static int obtenerIdUsuarioPorNombre(String nombreUsuario) {
        int id = -1;

        try {
            Connection conn = new ConnectionBD().connect();
            if (conn != null) {
                String sql = "{ call sp_ObtenerIdUsuarioPorNombre(?) }";
                CallableStatement stmt = conn.prepareCall(sql);
                stmt.setString(1, nombreUsuario);

                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    id = rs.getInt("IdUsuario");
                }

                rs.close();
                stmt.close();
                conn.close();
            }
        } catch (SQLException e) {
            Log.e("SQL_ERROR", "Error al obtener IdUsuario", e);
        }

        return id;
    }

    public void crearPedido(Context context, Pedido pedido, PedidoCallback callback) {
        String nombreCliente = NombreClienteFragment.nombreCliente;
        String observaciones = NotasEspecialesFragment.NotasEspecales; // o pedido.getObservaciones()
        Double Total = AñadirProductoAdapter.Total;
        List<DetallePedido> detallePedidos = AñadirProductoAdapter.listaDetalles;
        List<Producto> productos= ProductoRepository.obtenerProductos();

        new Thread(() -> {
            Connection connection = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                ConnectionBD connectionBD = new ConnectionBD();
                connection = connectionBD.connect();

                // Insertar pedido
                ps = connection.prepareStatement(
                        "INSERT INTO Pedidos (NombreCliente, ObservacionesEspeciales,Total) VALUES (?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, nombreCliente);
                ps.setString(2, observaciones);
                ps.setDouble(3, Total );
                ps.executeUpdate();

                rs = ps.getGeneratedKeys();
                idPedido = -1;
                if (rs.next()) {
                    idPedido = rs.getInt(1);
                }

                if (idPedido != -1) {
                    for (DetallePedido detalle : detallePedidos) {
                        String nombreProducto = detalle.getProducto();
                        int cantidad = detalle.getCantidad();

                        Producto producto = buscarProductoPorNombre(nombreProducto);
                        if (producto != null) {
                            int idProducto = producto.getId();
                            try (CallableStatement cs = connection.prepareCall("{ call sp_AgregarProductoAPedido(?, ?, ?) }")) {
                                cs.setInt(1, idPedido);
                                cs.setInt(2, idProducto);
                                cs.setInt(3, cantidad);
                                cs.execute();
                            }
                        } else {
                            Log.e("CrearPedido", "Producto no encontrado: " + nombreProducto);
                        }
                    }
                    // Todo salió bien
                    new Handler(Looper.getMainLooper()).post(callback::onSuccess);
                }

            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onError(e.getMessage()));
            } finally {
                try { if (rs != null) rs.close(); } catch (Exception ignored) {}
                try { if (ps != null) ps.close(); } catch (Exception ignored) {}
                try { if (connection != null) connection.close(); } catch (Exception ignored) {}
            }
        }).start();
    }



    private Producto buscarProductoPorNombre(String nombreProducto) {
        productosDisponibles= ProductoRepository.obtenerProductos();
        for (Producto p : productosDisponibles) {
            if (p.getNombre().equalsIgnoreCase(nombreProducto)) {
                return p;
            }
        }
        return null;
    }


}
