package com.example.tiaveneno.models;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private String id;
    private String nombreCliente;
    private String estado;
    private String solicitud;
    private String total;
    private String tiempo;
    private List<DetallePedido> detalles = new ArrayList<>();

    public Pedido() {}

    public Pedido(String id, String nombreCliente, String estado,
                  String solicitud, String total, String tiempo) {
        this.id = id;
        this.nombreCliente = nombreCliente;
        this.estado = estado;
        this.solicitud = solicitud;
        this.total = total;
        this.tiempo = tiempo;
    }

    // Getters
    public String getId() { return id; }
    public String getNombreCliente() { return nombreCliente; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) {
        this.estado = estado;
    }
    public void setNombreCliente(String setNombreCliente) { this.nombreCliente = nombreCliente; }
    public String getSolicitud() { return solicitud; }
    public String getTotal() { return total; }
    public String getTiempo() { return tiempo; }
    public List<DetallePedido> getDetalles() {
        return detalles;
    }
    public void agregarDetalle(DetallePedido detalle) {
        this.detalles.add(detalle);
    }
}