package com.example.tiaveneno;

import static com.example.tiaveneno.Repository.ProductoRepository.obtenerProductos;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tiaveneno.Adapter.ProductoAdministrarAdapter;
import com.example.tiaveneno.models.Producto;

import java.util.List;

public class AdministarProductoActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private ProductoAdministrarAdapter adapter;
    private List<Producto> listaProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administar_producto);

        recyclerView = findViewById(R.id.recyclerViewProductos);
        listaProductos = obtenerProductos();


        adapter = new ProductoAdministrarAdapter(this, listaProductos, new ProductoAdministrarAdapter.OnProductoClickListener() {
            @Override
            public void onProductoClick(Producto producto) {
                Toast.makeText(AdministarProductoActivity.this, "Producto seleccionado: " + producto.getNombre(), Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onEditarClick(Producto producto) {

            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}