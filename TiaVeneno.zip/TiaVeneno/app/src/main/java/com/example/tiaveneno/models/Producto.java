package com.example.tiaveneno.models;

public class Producto {
    private int id;
    private String nombre;
    private double precio;
    private int activo;
    private boolean seleccionado;

    public boolean isSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(boolean seleccionado) {
        this.seleccionado = seleccionado;
    }
    public Producto(){

    }

    public Producto(int id, String nombre, double precio, int activo) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.activo=activo;
    }

    public int getActivo() {
        return activo;
    }
    public void setActivo(int activo) {
        this.activo = activo;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getPrecio() { return precio; }
}
