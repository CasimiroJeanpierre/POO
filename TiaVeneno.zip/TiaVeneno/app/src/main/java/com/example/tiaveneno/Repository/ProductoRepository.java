package com.example.tiaveneno.Repository;

import android.util.Log;
import com.example.tiaveneno.Connection.ConnectionBD;
import com.example.tiaveneno.models.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoRepository {
    public static List<Producto> obtenerProductos() {
        List<Producto> productos = new ArrayList<>();
        ConnectionBD connectionBD = new ConnectionBD();
        Connection connection = connectionBD.connect();

        if (connection != null) {
            try {
                String sql = "SELECT IdProducto, NombreProducto, Precio, Activo FROM Productos";
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    int id = rs.getInt("IdProducto");
                    String nombre = rs.getString("NombreProducto");
                    double precio = rs.getDouble("Precio");
                    int activo=rs.getInt("Activo");

                    Producto producto = new Producto(id, nombre, precio,activo);
                    productos.add(producto);
                }

                rs.close();
                stmt.close();
                connection.close();

            } catch (SQLException e) {
                Log.e("SQL_ERROR", "Error al consultar productos", e);
                return null;
            }
        } else {
            Log.e("CONN_ERROR", "No se pudo conectar a la BD");
            return null;
        }

        return productos;
    }
    public static boolean actualizarEstadoProducto(int idProducto, int nuevoEstado) {
        try {
            ConnectionBD connetionBD = new ConnectionBD();
            Connection cn = connetionBD.connect();
            String sql = "UPDATE Productos SET Activo = ? WHERE IdProducto = ?";
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, nuevoEstado);
            ps.setInt(2, idProducto);

            int filas = ps.executeUpdate();
            ps.close();
            cn.close();

            return filas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
