package com.example.tiaveneno.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tiaveneno.R;
import com.example.tiaveneno.Repository.PedidoRepository;
import com.example.tiaveneno.Repository.ProductoRepository;
import com.example.tiaveneno.models.Producto;
import java.util.List;

public class ProductoAdministrarAdapter extends RecyclerView.Adapter<ProductoAdministrarAdapter.ProductoViewHolder> {

    private Context context;
    private List<Producto> listaProductos;
    private OnProductoClickListener listener;
    private ProductoRepository repo ;

    public interface OnProductoClickListener {
        void onProductoClick(Producto producto);
        void onEditarClick(Producto producto);
    }

    public ProductoAdministrarAdapter(Context context, List<Producto> listaProductos, OnProductoClickListener listener) {
        this.context = context;
        this.listaProductos = listaProductos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProductoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_administrar_producto, parent, false);
        return new ProductoAdministrarAdapter.ProductoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductoViewHolder holder, int position) {
        Producto producto = listaProductos.get(position);
        holder.txtNombre.setText(producto.getNombre());
        holder.txtPrecio.setText(String.format("S/ %.2f", producto.getPrecio()));

        // icono según activo
        if (producto.getActivo() == 1) {
            holder.btnToggle.setImageResource(R.drawable.ic_visibility);      // ojo abierto
        } else {
            holder.btnToggle.setImageResource(R.drawable.ic_visibility_off);  // ojo tachado
        }

        holder.btnToggle.setOnClickListener(v -> {
            int nuevoEstado = (producto.getActivo() == 1) ? 0 : 1;

            boolean actualizado = repo.actualizarEstadoProducto(producto.getId(), nuevoEstado);

            if (actualizado) {
                producto.setActivo(nuevoEstado);
                notifyItemChanged(holder.getAdapterPosition());
            } else {
                Toast.makeText(context, "Error al actualizar el estado", Toast.LENGTH_SHORT).show();
            }
        });

        holder.btnEditar.setOnClickListener(v -> {
            if (listener != null) {
                listener.onEditarClick(producto);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onProductoClick(producto);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }

    static class ProductoViewHolder extends RecyclerView.ViewHolder {
        TextView txtNombre, txtPrecio;
        ImageButton btnEditar, btnToggle;

        public ProductoViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNombre = itemView.findViewById(R.id.txtNombreProducto);
            txtPrecio = itemView.findViewById(R.id.txtPrecioProducto);
            btnEditar = itemView.findViewById(R.id.btnEditarProducto);
            btnToggle = itemView.findViewById(R.id.btnToggle);
        }
    }

}
