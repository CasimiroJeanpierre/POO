package com.example.tiaveneno;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tiaveneno.Connection.ConnectionBD;
import com.example.tiaveneno.DatosGlobales.DatosGlobales;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity {
    EditText usuario,clave;
    Button btnRegister;
    ImageButton  btnLogin;

    Connection con;

    public LoginActivity(){
        ConnectionBD instanceConnection = new ConnectionBD();
        con=instanceConnection.connect();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usuario = findViewById(R.id.txtUsuario);
        clave = findViewById(R.id.txtPassword);
        btnRegister = findViewById(R.id.btnRegister);
        btnLogin = findViewById(R.id.btnLogin);



        btnLogin.setOnClickListener(v -> {
            login();
        });


        btnRegister.setOnClickListener(v -> {
            Intent reg = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(reg);
        });
    }



    private void login() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        handler.post(() -> Toast.makeText(LoginActivity.this, "Iniciando sesión...", Toast.LENGTH_SHORT).show());

        executor.execute(() -> {
            String mensaje;
            String rolUsuario = null;  // Guardar el rol

            ConnectionBD instanceConnection = new ConnectionBD();
            Connection con = instanceConnection.connect();

            if (con == null) {
                mensaje = "Error de conexión";
            } else {
                try {
                    String sql = "SELECT * FROM [dbo].[Usuarios] WHERE Usuario='" + usuario.getText() +
                            "' AND contraseña='" + clave.getText() + "'";
                    Statement stm = con.createStatement();
                    ResultSet rs = stm.executeQuery(sql);

                    if (rs.next()) {
                        // Usuario encontrado
                        rolUsuario = rs.getString("Rol");  // Cambia "Rol" por el nombre exacto de tu campo rol
                        DatosGlobales.idUsuarioActual = usuario.getText().toString();
                        mensaje = "Bienvenido";
                    } else {
                        mensaje = "Usuario o contraseña incorrecto";
                    }
                    rs.close();
                    stm.close();
                    con.close();
                } catch (Exception e) {
                    Log.e("Error de conexión SQL: ", e.getMessage() != null ? e.getMessage() : "Error Desconocido");
                    mensaje = "Error de conexión SQL";
                }
            }

            String finalMensaje = mensaje;
            String finalRolUsuario = rolUsuario;

            handler.post(() -> {
                Toast.makeText(LoginActivity.this, finalMensaje, Toast.LENGTH_LONG).show();

                if ("Bienvenido".equals(finalMensaje)) {
                    if ("Administrador".equalsIgnoreCase(finalRolUsuario)) {
                        // Si es administrador
                        Intent intentAdmin = new Intent(getApplicationContext(), PedidosAdminActivity.class);
                        startActivity(intentAdmin);
                    } else if ("Vendedor".equalsIgnoreCase(finalRolUsuario)) {
                        // Si es vendedor
                        Intent intentVendedor = new Intent(getApplicationContext(), PedidosVendedorActivity.class);
                        startActivity(intentVendedor);
                    } else {
                        // Otro rol o sin rol definido
                        Toast.makeText(LoginActivity.this, "Rol de usuario no definido", Toast.LENGTH_SHORT).show();
                    }

                    // Limpias los campos después de iniciar actividad
                    usuario.setText("");
                    clave.setText("");
                }
            });
        });
    }

}