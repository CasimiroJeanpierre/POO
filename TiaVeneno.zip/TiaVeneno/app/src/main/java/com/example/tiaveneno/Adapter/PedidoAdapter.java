package com.example.tiaveneno.Adapter;


import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.tiaveneno.models.Pedido;
import java.util.ArrayList;
import java.util.List;
import com.example.tiaveneno.databinding.ItemPedidoBinding;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.PedidoViewHolder> {

    private List<Pedido> pedidosOriginales;
    private List<Pedido> pedidosFiltrados;
    private OnActualizarClickListener listener;

    public interface OnActualizarClickListener {
        void onActualizarClick(Pedido pedido);
    }

    public PedidoAdapter(List<Pedido> pedidos, OnActualizarClickListener listener) {
        this.pedidosOriginales = pedidos != null ? new ArrayList<>(pedidos) : new ArrayList<>();
        this.pedidosFiltrados = new ArrayList<>(this.pedidosOriginales);
        this.listener = listener;
    }

    @NonNull
    @Override
    public PedidoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPedidoBinding binding = ItemPedidoBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PedidoViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PedidoViewHolder holder, int position) {
        Pedido pedido = pedidosFiltrados.get(position);
        holder.bind(pedido);
    }

    @Override
    public int getItemCount() {
        return pedidosFiltrados.size();
    }

    public void filtrarPedidosPorEstado(boolean activos) {
        pedidosFiltrados.clear();
        for (Pedido p : pedidosOriginales) {
            if (activos && (
                    p.getEstado().equals("En Preparación") ||
                            p.getEstado().equals("Listo para Recoger") ||
                            p.getEstado().equals("Recibido")
            )) {
                pedidosFiltrados.add(p);
            } else if (!activos && p.getEstado().equals("Completado")) {
                pedidosFiltrados.add(p);
            }
        }
        notifyDataSetChanged();
    }

    public void updatePedidos(List<Pedido> nuevosPedidos) {
        if (nuevosPedidos == null) return;
        pedidosOriginales.clear();
        pedidosOriginales.addAll(nuevosPedidos);
        pedidosFiltrados.clear();
        pedidosFiltrados.addAll(nuevosPedidos);
        notifyDataSetChanged();
    }

    class PedidoViewHolder extends RecyclerView.ViewHolder {
        ItemPedidoBinding binding;

        public PedidoViewHolder(ItemPedidoBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Pedido pedido) {
            binding.tvNombreCliente.setText(pedido.getNombreCliente());
            binding.tvIdPedido.setText("ID: " + pedido.getId());
            binding.tvSolicitud.setText(pedido.getSolicitud());
            binding.tvTotal.setText("Total: " + pedido.getTotal());
            binding.tvTiempo.setText(pedido.getTiempo());
            binding.tvEstado.setText(pedido.getEstado());

            String colorEstado;
            switch (pedido.getEstado()) {
                case "En Preparación":
                    colorEstado = "#F7B733";
                    break;
                case "Listo para Recoger":
                    colorEstado = "#A3C9A8";
                    break;
                case "Recibido":
                    colorEstado = "#6EC1E4";
                    break;
                case "Completado":
                    colorEstado = "#2AA850";
                    break;
                default:
                    colorEstado = "#D3D3D3";
            }
            binding.tvEstado.setBackgroundColor(Color.parseColor(colorEstado));

            // Adapter de detalles
            ArticuloAdapter detalleAdapter = new ArticuloAdapter(pedido.getDetalles());
            binding.rvDetallePedidos.setLayoutManager(new LinearLayoutManager(binding.rvDetallePedidos.getContext()));
            binding.rvDetallePedidos.setAdapter(detalleAdapter);

            // Botón "Actualizar Estado"
            binding.btnActualizarEstado.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onActualizarClick(pedido);
                }
            });
        }
    }



}

