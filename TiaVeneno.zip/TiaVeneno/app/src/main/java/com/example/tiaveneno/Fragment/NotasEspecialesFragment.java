package com.example.tiaveneno.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.tiaveneno.R;

public class NotasEspecialesFragment extends Fragment {

    Button btnCrearPedido;
    EditText etnotas;
    public static String NotasEspecales;
    public static NotasEspecialesFragment newInstance(String param1, String param2) {
        NotasEspecialesFragment fragment = new NotasEspecialesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notas_especiales, container, false);
        // Inflate the layout for this fragment

        btnCrearPedido=view.findViewById(R.id.btnCrearPedido);
        etnotas=view.findViewById(R.id.etNotas);


        btnCrearPedido.setOnClickListener(v -> {
            NotasEspecales = etnotas.getText().toString();
            Fragment confirmarFragment = new PedidoCreadoFragment();

            // Cambia el fragmento
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, confirmarFragment) // Asegúrate que R.id.fragment_container es el id del contenedor en tu activity
                    .addToBackStack(null) // Opcional: permite volver con el botón atrás
                    .commit();
        });
        return view;
    }
}